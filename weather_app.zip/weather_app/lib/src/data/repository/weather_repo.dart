class WeatherRepo {

}
